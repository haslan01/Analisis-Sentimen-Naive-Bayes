#UPDATES
- January, 2016 [758 words] - First init add stopwords list from reference [1] 

#REFERENCES
- [1] Tala, F. Z. (2003). A Study of Stemming Effects on Information Retrieval in Bahasa Indonesia. M.Sc. Thesis. Master of Logic Project. Institute for Logic, Language and Computation. Universiteit van Amsterdam, The Netherlands.

