# Kamus Alay - Colloquial Indonesian Lexicon

Assalamu'alaikum!

Halo. Apabila ingin 'bermain-main' atau ingin diskusi mengenai dataset kamus-alay, silakan kirim email ke nikmatunaliyahsalsabila@gmail.com :) 
Semoga bisa bermanfaat dan menghasilkan karya keren nantinya!

Publikasi mengenai dataset ini dapat dilihat di https://ieeexplore.ieee.org/abstract/document/8629151

--


Assalamu'alaikum. Hello! Hi! 
Hopefully, this lexicon is useful for your great work!

Send me an email to nikmatunaliyahsalsabila@mail.com if there's any feedback or anything related to the lexicon.

See publication on the link: https://ieeexplore.ieee.org/abstract/document/8629151




Regards,

Salsabila, Ali, Yosef, and Ade
